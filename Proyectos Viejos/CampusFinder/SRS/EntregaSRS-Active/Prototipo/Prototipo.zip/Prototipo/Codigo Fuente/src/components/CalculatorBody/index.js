import React from 'react'
import WorkingOnIt from '../WorkingOnIt'

class CalculatorBody extends React.Component{
	constructor(props){
		super(props);
		this.state={}
	}

	render(){
		return(<WorkingOnIt/>);
	}
}

export default CalculatorBody;
