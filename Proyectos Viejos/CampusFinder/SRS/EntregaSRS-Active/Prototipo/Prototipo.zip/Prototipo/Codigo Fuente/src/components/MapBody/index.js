import React from 'react'
import WorkingOnIt from '../WorkingOnIt'

class MapBody extends React.Component{
	constructor(props){
		super(props);
		this.state={}
	}

	render(){
		return(<WorkingOnIt/>);
	}
}

export default MapBody;
